import { FC } from "react";
import { Product } from "../App";

import "./ProductCard.css"


const ProductCard: FC<Product> = ({img_src, price, weight, name}: Product) => {
    return ( 
        <div className="card_container">
            <img className="card_image" src={img_src} alt="" />
            <span className="card_price">{price}$</span>
            <span className="card_name">{name}</span>
            <span className="card_weight">{weight}g.</span>
        </div>
    );
}

export default ProductCard;