import { useState } from 'react';
import ProductCard from './components/ProductCard';

import './App.css';

export type Product = {
    name: string;
    img_src: string;
    price: number;
    weight: number;
}

function App() {
    const [products, setProducts] = useState<Product[]>([
        {img_src: "https://eda.yandex/images/15441079/0d09e9b391b58f23108d7de91f43de26-216x188.jpeg", price: 10, weight: 200, name: "Samara vibes"},
        {img_src: "https://eda.yandex/images/15441079/3345f731bd1de2b3c1fe415a6e4b56fd-216x188.jpeg", price: 30, weight: 400, name: "Kalach ua"},
        {img_src: "https://eda.yandex/images/15252145/2e3595fabe130f69f1a70deb6df113f2-216x188.jpeg", price: 5, weight: 300, name: "Igor start kit"},
        {img_src: "https://eda.yandex/images/3508859/113d03704c034c41740d6d181acc4c33-216x188.jpeg", price: 6, weight: 220, name: "Boom"},
        {img_src: "https://eda.yandex/images/3806315/14a9f708fa28757cbee9daee95178a49-216x188.jpeg", price: 4, weight: 150, name: "Baby sasuke"},
        {img_src: "https://eda.yandex/images/1365461/e18ed97b0f1fd6a9aa358efb82c7e359-216x188.jpeg", price: 8, weight: 230, name: "Marim"},
        {img_src: "https://eda.yandex/images/3806466/4a5f726c1c2a1c79953d53482cfc329a-216x188.jpeg", price: 12, weight: 200, name: "Krug"},
        {img_src: "https://eda.yandex/images/3435765/802936e8fd5880aff83ffe130933bdd0-216x188.jpeg", price: 43, weight: 120, name: "Limonad"},
    ]);

    return (
        <div className="App">
            <div className='product_list'>
                {products.map(product => 
                    <ProductCard 
                        img_src={product.img_src}
                        price={product.price}
                        weight={product.weight}
                        name={product.name}    
                    />
                )}
            </div>
        </div>
    );
}

export default App;
